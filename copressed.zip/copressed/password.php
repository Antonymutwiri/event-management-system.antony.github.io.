<?php
$password = "12345";
$pass = md5($password);
echo $pass;