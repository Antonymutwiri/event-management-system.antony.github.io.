<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
include('./db_connect.php');
ob_start();
if(!isset($_SESSION['system'])){
	$system = $conn->query("SELECT * FROM system_settings limit 1")->fetch_array();
	foreach($system as $k => $v){
		$_SESSION['system'][$k] = $v;
	}
}
ob_end_flush();
?>
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Event Management System</title>
 	

<?php include('./header.php'); ?>
<?php 
if(isset($_SESSION['login_id']))
// header("location:index.php?page=home");

?> 

</head>
<style>
	body{
		width: 100%;
	    height: calc(100%);
	    /*background: #007bff;*/
	}
	main#main{
		width:100%;
		height: calc(100%);
		background:white;
	}
	#login-right{
		position: absolute;
		right:0;
		width:40%;
		height: calc(100%);
		background:white;
		display: flex;
		align-items: center;
	}
	#login-left{
		position: absolute;
		left:0;
		width:60%;
		height: calc(100%);
		display: flex;
		align-items: center;
		/*background: url(assets/uploads/<?php echo $_SESSION['system']['cover_img'] ?>);*/
		background:#28a745;
	    background-repeat: no-repeat;
	    background-size: cover;
	}
	#login-right .card{
		margin: auto;
		z-index: 1
	}
	.logo {
    margin: auto;
    font-size: 8rem;
    padding: .5em 0.8em;
    color: #000000b3;
}
</style>

<body>


  <main id="main" class=" bg-black">
		<nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="./"><?php echo $_SESSION['system']['name'] ?></a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="/index.php?page=home">Home</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="/index.php?page=venue">Venues</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="/index.php?page=about">About</a></li>

                        <?php
                        session_start();

                        if(isset($_SESSION['login_id'])) {
                            // User is logged in, display user information
                            echo '<li class="nav-item"><a class="nav-link js-scroll-trigger" href="/admin/index.php">Welcome User </a></li>';
                            echo '<li class="nav-item"><a class="nav-link js-scroll-trigger" href="/admin/ajax.php?action=logout">Logout </a></li>';

                            // Add code to display user information here
                        } else {
                            // User is not logged in, display login and register links
                            echo '<li class="nav-item"><a class="nav-link js-scroll-trigger" href="/admin/index.php?page=login">Login</a></li>';
                            echo '<li class="nav-item"><a class="nav-link js-scroll-trigger" href="/admin/register.php">Register</a></li>';
                            

                          }
                        ?>                        
                     
                    </ul>
                </div>
            </div>
        </nav>
  		<div id="login-left">
  			<div class="logo">
  				<img src="assets/uploads/admin-logo/itlogo1.png">
  			</div>
  		</div>

  		<div id="login-right">
  			<div class="w-100">
  				<h4 class="text-success text-center"><b><?php echo $_SESSION['system']['name'] ?></b></h4>
  				<br>

  			<div class="card col-md-8">
  				<div class="card-body">
  						
  					<form id="signup-form">
                        <div class="form-group">
                            <label for="name" class="control-label text-success">Name</label>
                            <input type="text" id="name" name="name" class="form-control">
                        </div>
						<!-- <div class="form-group">
							<label for="username" class="control-label text-success">Username</label>
							<input type="text" id="username" name="username" class="form-control">
						</div> -->
                        <div class="form-group">
                            <label for="email" class="control-label text-success">Email</label>
                            <input type="email" id="email" name="email" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="password" class="control-label">Password</label>
                            <input type="password" id="password" name="password" class="form-control">
                        </div>
                        <center><button class="btn-sm btn-block btn-wave col-md-4 btn-success">Signup</button></center>
                    </form>
  				</div>
  			</div>
  			</div>
  		</div>
   

  </main>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>


</body>
<script>
	$('#signup-form').submit(function(e){
    e.preventDefault();
    $('#signup-form button[type="button"]').attr('disabled', true).html('Signing up...');
    if($(this).find('.alert-danger').length > 0) {
        $(this).find('.alert-danger').remove();
    }
    $.ajax({
        url: 'ajax.php?action=signup',
        method: 'POST',
        data: $(this).serialize(),
        error: err => {
            console.log(err);
            $('#signup-form button[type="button"]').removeAttr('disabled').html('Signup');
        },
        success: function(resp){
            if(resp == 1){
                location.href = 'index.php?page=home';
            } else {
                // $('#signup-form').prepend('<div class="alert alert-danger">Signup failed. Please try again.</div>');
                $('#signup-form').prepend('<div class="alert alert-danger">User already exist.Please login. or Sign up with different email</div>');
                $('#signup-form button[type="button"]').removeAttr('disabled').html('Signup');
            }
        }
    });
});
</script>	
</html>